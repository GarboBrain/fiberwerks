// fiberwerks-website/src/App.js

import React from 'react';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <header className="flex justify-between items-center p-6 border-b border-gray-800">
        <h1 className="text-3xl font-bold tracking-widest">fiberwerks</h1>
        <nav className="space-x-6">
          <a href="#about" className="hover:underline">About</a>
          <a href="#gallery" className="hover:underline">Gallery</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>

      <main className="p-6 md:p-12">
        <section className="text-center my-20">
          <h2 className="text-5xl font-light leading-tight">Custom Fiberglass for Iconic Porsche Builds</h2>
          <p className="mt-6 text-lg text-gray-400 max-w-xl mx-auto">
            Precision-crafted, retro-inspired fiberglass parts for Porsche 911s. Born in the UAE. Built for the road.
          </p>
        </section>

        <section id="about" className="my-20 max-w-4xl mx-auto text-center">
          <h3 className="text-3xl mb-4">About Fiberwerks</h3>
          <p className="text-gray-400">
            Fiberwerks creates unique, hand-designed fiberglass panels for vintage Porsche enthusiasts. With a design philosophy inspired by classic racing lines and minimalist craftsmanship, every part we build blends performance, function, and aesthetic purity.
          </p>
        </section>

        <section id="gallery" className="my-20">
          <h3 className="text-3xl text-center mb-8">Gallery</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-gray-800 h-64 animate-pulse"></div>
            <div className="bg-gray-800 h-64 animate-pulse"></div>
            <div className="bg-gray-800 h-64 animate-pulse"></div>
          </div>
        </section>

        <section id="contact" className="my-20 text-center">
          <h3 className="text-3xl mb-4">Contact Us</h3>
          <p className="text-gray-400 mb-6">
            Got a custom Porsche project in mind? Let’s talk.
          </p>
          <form className="max-w-md mx-auto space-y-4">
            <input type="text" placeholder="Name" className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded" />
            <input type="email" placeholder="Email" className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded" />
            <textarea placeholder="Message" rows="4" className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded"></textarea>
            <button type="submit" className="px-6 py-2 bg-white text-black font-bold rounded hover:bg-gray-200 transition">Send</button>
          </form>
        </section>
      </main>

      <footer className="text-center text-gray-600 p-6 border-t border-gray-800">
        © 2025 fiberwerks. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
